//
//  AppDelegate.h
//  Invaders
//
//  Created by Kent Miller on 1/19/16.
//  Copyright © 2016 emulator 101. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

