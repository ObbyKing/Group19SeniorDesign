//
//  font4x5.h
//  Chip8
//

#ifndef Chip8_font4x5_h
#define Chip8_font4x5_h

#include <stdint.h>

#define FONT_BASE 0
#define FONT_SIZE 5*16

extern uint8_t font4x5[];

#endif
